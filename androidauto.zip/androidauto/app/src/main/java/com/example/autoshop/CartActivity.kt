package com.example.autoshop

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.autoshop.model.CartManager
import com.example.autoshop.model.Product
import com.google.android.material.snackbar.Snackbar
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class CartActivity : AppCompatActivity() {

    private lateinit var cartContainer: LinearLayout
    private lateinit var tvTotalPrice: TextView
    private lateinit var tvRentalDays: TextView
    private lateinit var btnCheckout: Button
    private lateinit var btnRemove: Button
    private lateinit var btnDecreaseDays: Button
    private lateinit var btnIncreaseDays: Button

    // Dátum választó változók
    private lateinit var btnPickDates: Button
    private lateinit var tvDateRange: TextView
    private var startDate: Calendar? = null
    private var endDate: Calendar? = null

    // Ezek lehetnek null értékűek, ha nem találhatóak
    private var ivCartImage: ImageView? = null
    private var tvCartName: TextView? = null
    private var tvCartDescription: TextView? = null
    private var tvDailyPrice: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cart)

        supportActionBar?.hide()

        // Csak azokat az elemeket keresd meg, amelyek biztosan léteznek
        cartContainer = findViewById(R.id.cartContainer)
        tvTotalPrice = findViewById(R.id.tvTotalPrice)
        tvRentalDays = findViewById(R.id.tvRentalDays)
        btnCheckout = findViewById(R.id.btnCheckout)
        btnRemove = findViewById(R.id.btnRemove)
        btnDecreaseDays = findViewById(R.id.btnDecreaseDays)
        btnIncreaseDays = findViewById(R.id.btnIncreaseDays)

        // Ezek lehetnek null-ok, ha nem léteznek az XML-ben
        ivCartImage = findViewById(R.id.ivCartImage)
        tvCartName = findViewById(R.id.tvCartName)
        tvCartDescription = findViewById(R.id.tvCartDescription)
        tvDailyPrice = findViewById(R.id.tvDailyPrice)

        // Dátum választó elemek - HA NINCSENEK, LÉTREHOZZUK
        btnPickDates = findViewById(R.id.btnPickDates) ?: createDatePickerButton()
        tvDateRange = findViewById(R.id.tvDateRange) ?: createDateRangeTextView()

        val btnBack = findViewById<Button>(R.id.btnBack)
        btnBack.setOnClickListener {
            finish()
        }

        btnDecreaseDays.setOnClickListener {
            val currentDays = CartManager.getRentalDays()
            if (currentDays > 1) {
                CartManager.setRentalDays(currentDays - 1)
                updateRentalInfo()
            }
        }

        btnIncreaseDays.setOnClickListener {
            CartManager.setRentalDays(CartManager.getRentalDays() + 1)
            updateRentalInfo()
        }

        btnRemove.setOnClickListener {
            CartManager.removeProduct()
            refreshCart()
            Snackbar.make(cartContainer, "Autó eltávolítva", Snackbar.LENGTH_SHORT).show()
        }

        btnPickDates.setOnClickListener {
            showDatePickerDialog()
        }

        btnCheckout.setOnClickListener {
            if (CartManager.hasSelectedCar()) {
                showCustomerInfoDialog()
            } else {
                Toast.makeText(this, "Előbb válassz autót!", Toast.LENGTH_SHORT).show()
            }
        }

        refreshCart()
        updateRentalInfo()
        updateDateDisplay()
    }

    private fun createDatePickerButton(): Button {
        val button = Button(this).apply {
            text = "📅 Dátum kiválasztása"
            id = R.id.btnPickDates
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(16, 16, 16, 16)
            }
        }
        cartContainer.addView(button, 1) // Második pozícióba teszi
        return button
    }

    private fun createDateRangeTextView(): TextView {
        val textView = TextView(this).apply {
            id = R.id.tvDateRange
            text = "Dátum: Nincs kiválasztva"
            textSize = 16f
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(16, 0, 16, 16)
            }
        }
        cartContainer.addView(textView, 2) // Harmadik pozícióba teszi
        return textView
    }

    private fun refreshCart() {
        val cartItems = CartManager.getCartItems()

        // Keresd meg az elemeket
        val tvEmptyCart = findViewById<TextView>(R.id.tvEmptyCart)
        val carDetailsLayout = findViewById<LinearLayout>(R.id.carDetailsLayout)
        val datePickerLayout = findViewById<LinearLayout>(R.id.datePickerLayout)
        val rentalDaysLayout = findViewById<LinearLayout>(R.id.rentalDaysLayout)
        val summaryLayout = findViewById<LinearLayout>(R.id.summaryLayout)

        if (cartItems.isEmpty()) {
            // ÜRES KOSÁR
            tvEmptyCart?.visibility = android.view.View.VISIBLE
            carDetailsLayout?.visibility = android.view.View.GONE
            datePickerLayout?.visibility = android.view.View.GONE
            rentalDaysLayout?.visibility = android.view.View.GONE
            summaryLayout?.visibility = android.view.View.GONE

            btnCheckout.isEnabled = false
            btnRemove.isEnabled = false

        } else {
            // VAN AUTÓ
            tvEmptyCart?.visibility = android.view.View.GONE
            carDetailsLayout?.visibility = android.view.View.VISIBLE
            datePickerLayout?.visibility = android.view.View.VISIBLE
            rentalDaysLayout?.visibility = android.view.View.VISIBLE
            summaryLayout?.visibility = android.view.View.VISIBLE

            val car = cartItems.first()

            ivCartImage?.setImageResource(car.imageResId)
            tvCartName?.text = car.name
            tvCartDescription?.text = car.description
            tvDailyPrice?.text = "${String.format("%,d", car.dailyPrice)} Ft/nap"

            btnCheckout.isEnabled = true
            btnRemove.isEnabled = true

            // Dátumok frissítése
            updateDateDisplay()
        }

        // Ár frissítése
        updateRentalInfo()
    }

    private fun updateRentalInfo() {
        val days = CartManager.getRentalDays()
        tvRentalDays.text = "$days nap"
        tvTotalPrice.text = "Összesen: ${String.format("%,d", CartManager.getTotalPrice())} Ft"
    }

    private fun updateDateDisplay() {
        if (startDate != null && endDate != null) {
            val format = SimpleDateFormat("yyyy.MM.dd", Locale.getDefault())
            val startStr = format.format(startDate!!.time)
            val endStr = format.format(endDate!!.time)

            val days = calculateDaysBetween()
            tvDateRange.text = "Dátum: $startStr - $endStr ($days nap)"

            // Frissítsd a bérlési napokat is
            CartManager.setRentalDays(days)
            updateRentalInfo()
        } else {
            tvDateRange.text = "Dátum: Nincs kiválasztva"
        }
    }

    private fun showDatePickerDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_date_picker, null)

        val tvStartDate = dialogView.findViewById<TextView>(R.id.tvStartDate)
        val tvEndDate = dialogView.findViewById<TextView>(R.id.tvEndDate)
        val tvTotalDays = dialogView.findViewById<TextView>(R.id.tvTotalDays)
        val btnConfirmDates = dialogView.findViewById<Button>(R.id.btnConfirmDates)

        // Kezdő dátum kezelése
        dialogView.findViewById<Button>(R.id.btnStartDate).setOnClickListener {
            showCalendarPicker(isStartDate = true) { selectedCalendar ->
                startDate = selectedCalendar
                tvStartDate.text = "Kezdés: ${formatDate(selectedCalendar)}"
                updateDateDialogInfo(tvTotalDays, btnConfirmDates)
            }
        }

        // Vég dátum kezelése
        dialogView.findViewById<Button>(R.id.btnEndDate).setOnClickListener {
            showCalendarPicker(isStartDate = false) { selectedCalendar ->
                endDate = selectedCalendar
                tvEndDate.text = "Vége: ${formatDate(selectedCalendar)}"
                updateDateDialogInfo(tvTotalDays, btnConfirmDates)
            }
        }

        // Megerősítés gomb
        btnConfirmDates.setOnClickListener {
            if (startDate != null && endDate != null) {
                updateDateDisplay()
                Toast.makeText(this, "Dátumok mentve!", Toast.LENGTH_SHORT).show()
            }
        }

        // Dialógus megjelenítése
        AlertDialog.Builder(this)
            .setTitle("Bérlési dátumok")
            .setView(dialogView)
            .setPositiveButton("Bezár", null)
            .show()
    }

    private fun showCalendarPicker(isStartDate: Boolean, onDateSelected: (Calendar) -> Unit) {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val datePicker = android.app.DatePickerDialog(
            this,
            { _, selectedYear, selectedMonth, selectedDay ->
                val selectedCalendar = Calendar.getInstance().apply {
                    set(selectedYear, selectedMonth, selectedDay)
                }

                // Ellenőrzés: vég dátum ne legyen korábbi, mint kezdő dátum
                if (!isStartDate && startDate != null && selectedCalendar.before(startDate)) {
                    Toast.makeText(this, "A vég dátum nem lehet korábbi, mint a kezdő!", Toast.LENGTH_SHORT).show()
                    return@DatePickerDialog
                }

                onDateSelected(selectedCalendar)
            },
            year,
            month,
            day
        )

        // Ha kezdő dátumot választunk, ne legyen korábban, mint mai nap
        if (isStartDate) {
            datePicker.datePicker.minDate = System.currentTimeMillis() - 1000
        }
        // Ha vég dátumot választunk és van kezdő dátum, legyen legalább kezdő dátum
        else if (startDate != null) {
            datePicker.datePicker.minDate = startDate!!.timeInMillis
        }

        datePicker.show()
    }

    private fun updateDateDialogInfo(tvTotalDays: TextView, btnConfirm: Button) {
        if (startDate != null && endDate != null) {
            val days = calculateDaysBetween()
            tvTotalDays.text = "Összesen: $days nap"
            btnConfirm.isEnabled = days > 0

            if (days <= 0) {
                Toast.makeText(this, "A vég dátumnak későbbinek kell lennie!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun calculateDaysBetween(): Int {
        if (startDate == null || endDate == null) return 0

        val diff = endDate!!.timeInMillis - startDate!!.timeInMillis
        val days = (diff / (1000 * 60 * 60 * 24)).toInt() + 1 // +1 mert a kezdő nap is beleszámít

        return days.coerceAtLeast(1)
    }

    private fun formatDate(calendar: Calendar): String {
        val format = SimpleDateFormat("yyyy.MM.dd", Locale.getDefault())
        return format.format(calendar.time)
    }

    private fun showCustomerInfoDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_customer_info, null)

        val etName = dialogView.findViewById<EditText>(R.id.etName)
        val etPhone = dialogView.findViewById<EditText>(R.id.etPhone)
        val btnConfirm = dialogView.findViewById<Button>(R.id.btnConfirmOrder)

        val dialog = AlertDialog.Builder(this)
            .setTitle("Személyes adatok")
            .setView(dialogView)
            .setCancelable(false)
            .create()

        btnConfirm.setOnClickListener {
            val name = etName.text.toString().trim()
            val phone = etPhone.text.toString().trim()

            if (name.isEmpty() || phone.isEmpty()) {
                Toast.makeText(this, "Töltsd ki mindkét mezőt!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (phone.length < 10) {
                Toast.makeText(this, "Érvényes telefonszámot adj meg!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            CartManager.setCustomerData(name, phone)

            showConfirmationDialog()
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun showConfirmationDialog() {
        val car = CartManager.getCartItems().firstOrNull()

        if (car == null) {
            Toast.makeText(this, "Nincs kiválasztott autó!", Toast.LENGTH_SHORT).show()
            return
        }

        val days = CartManager.getRentalDays()
        val total = CartManager.getTotalPrice()
        val name = CartManager.getCustomerName()

        // Dátumok formázása
        val dateRange = if (startDate != null && endDate != null) {
            "${formatDate(startDate!!)} - ${formatDate(endDate!!)}"
        } else {
            "Nincs dátum kiválasztva"
        }

        AlertDialog.Builder(this)
            .setTitle("Kölcsönzés megerősítése")
            .setMessage(
                """
                Kölcsönzés összegzése:
                
                🚗 Autó: ${car.name}
                📅 Dátum: $dateRange
                ⏱️ Bérlési idő: $days nap
                💰 Napi díj: ${String.format("%,d", car.dailyPrice)} Ft
                💵 Összesen: ${String.format("%,d", total)} Ft
                
                👤 Ügyfél: $name
                
                Kölcsönzés megerősítve!
                """.trimIndent()
            )
            .setPositiveButton("Rendben") { dialog, _ ->
                Toast.makeText(this, "Sikeres kölcsönzés!", Toast.LENGTH_LONG).show()
                CartManager.clearCart()
                finish()
            }
            .setNegativeButton("Mégse", null)
            .show()
    }
}