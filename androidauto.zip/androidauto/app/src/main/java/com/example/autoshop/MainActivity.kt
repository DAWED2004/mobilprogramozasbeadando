package com.example.autoshop

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.autoshop.model.CartManager
import com.example.autoshop.model.Product
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {

    private lateinit var productsContainer: LinearLayout

    private val cars = listOf(
        Product(
            id = 1,
            name = "Volkswagen Golf 1.6 TSI",
            description = "Modern turbóbenzin motor, automata váltó, klíma",
            dailyPrice = 15000, // NAPI bérleti díj
            imageResId = R.drawable.vw
        ),
        Product(
            id = 2,
            name = "BMW 320d",
            description = "2.0 dízel, teljes felszereltség, navigáció",
            dailyPrice = 25000,
            imageResId = R.drawable.bmw
        ),
        Product(
            id = 3,
            name = "Toyota Prius Hybrid",
            description = "Hibrid hajtás, alacsony fogyasztás, biztonságos",
            dailyPrice = 18000,
            imageResId = R.drawable.toyota
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        supportActionBar?.hide()

        productsContainer = findViewById(R.id.productsContainer)
        val btnOpenCart = findViewById<Button>(R.id.btnOpenCart)

        inflateCars()

        btnOpenCart.setOnClickListener {
            startActivity(Intent(this, CartActivity::class.java))
        }
    }

    private fun inflateCars() {
        val inflater = LayoutInflater.from(this)
        productsContainer.removeAllViews()

        for (car in cars) {
            val itemView = inflater.inflate(R.layout.item_car, productsContainer, false)

            val ivCarImage = itemView.findViewById<ImageView>(R.id.ivCarImage)
            val tvCarName = itemView.findViewById<TextView>(R.id.tvCarName)
            val tvCarDescription = itemView.findViewById<TextView>(R.id.tvCarDescription)
            val tvCarPrice = itemView.findViewById<TextView>(R.id.tvCarPrice)
            val btnRent = itemView.findViewById<Button>(R.id.btnRent)

            ivCarImage.setImageResource(car.imageResId)
            tvCarName.text = car.name
            tvCarDescription.text = car.description
            tvCarPrice.text = "${String.format("%,d", car.dailyPrice)} Ft/nap"

            btnRent.setOnClickListener {
                showRentalDialog(car)
            }

            productsContainer.addView(itemView)
        }
    }

    private fun showRentalDialog(product: Product) {
        val dialogView = layoutInflater.inflate(R.layout.dialog_rental, null)

        val ivDetailImage = dialogView.findViewById<ImageView>(R.id.ivDetailImage)
        val tvDetailName = dialogView.findViewById<TextView>(R.id.tvDetailName)
        val tvDetailDescription = dialogView.findViewById<TextView>(R.id.tvDetailDescription)
        val tvDetailPrice = dialogView.findViewById<TextView>(R.id.tvDetailPrice)
        val btnRentNow = dialogView.findViewById<Button>(R.id.btnRentNow)

        ivDetailImage.setImageResource(product.imageResId)
        tvDetailName.text = product.name
        tvDetailDescription.text = product.description
        tvDetailPrice.text = "${String.format("%,d", product.dailyPrice)} Ft/nap"

        val dialog = AlertDialog.Builder(this)
            .setTitle("Autó kölcsönzése")
            .setView(dialogView)
            .setCancelable(true)
            .create()

        btnRentNow.setOnClickListener {
            // DEBUG: Ellenőrzés
            println("DEBUG: Kattintás a kölcsönzésre: ${product.name}")

            CartManager.addProduct(product)
            CartManager.debugCart() // Debug kiírás

            Snackbar.make(
                dialogView,
                "✅ ${product.name} hozzáadva!",
                Snackbar.LENGTH_LONG
            ).show()

            dialog.dismiss()

            // Azonnal mutasd a kosarat
            startActivity(Intent(this, CartActivity::class.java))
        }

        dialog.show()
    }
}
