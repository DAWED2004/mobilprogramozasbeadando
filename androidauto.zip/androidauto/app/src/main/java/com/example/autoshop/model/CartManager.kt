package com.example.autoshop.model

object CartManager {
    private val cartItems = mutableListOf<Product>()
    private var rentalDays: Int = 1
    private var customerName: String = ""
    private var customerPhone: String = ""

    fun addProduct(product: Product) {
        // Töröld először a régi elemet, majd add hozzá az újat
        cartItems.clear()
        cartItems.add(product)
        println("DEBUG: Autó hozzáadva: ${product.name}") // Debug üzenet
    }

    fun getCartItems(): List<Product> = cartItems.toList()

    fun getTotalPrice(): Int {
        return if (cartItems.isNotEmpty()) {
            cartItems.first().dailyPrice * rentalDays
        } else {
            0
        }
    }

    fun clearCart() {
        cartItems.clear()
        rentalDays = 1
        customerName = ""
        customerPhone = ""
        println("DEBUG: Kosár kiürítve") // Debug üzenet
    }

    fun setRentalDays(days: Int) {
        rentalDays = days.coerceAtLeast(1)
        println("DEBUG: Bérlési napok: $rentalDays") // Debug üzenet
    }

    fun getRentalDays(): Int = rentalDays

    fun setCustomerData(name: String, phone: String) {
        customerName = name
        customerPhone = phone
    }

    fun getCustomerName(): String = customerName
    fun getCustomerPhone(): String = customerPhone

    fun removeProduct() {
        cartItems.clear()
        println("DEBUG: Autó eltávolítva") // Debug üzenet
    }

    fun hasSelectedCar(): Boolean = cartItems.isNotEmpty()

    // Új: Ellenőrző funkció
    fun debugCart() {
        println("=== KOSÁR DEBUG ===")
        println("Elemek száma: ${cartItems.size}")
        cartItems.forEachIndexed { index, product ->
            println("$index: ${product.name} - ${product.dailyPrice} Ft")
        }
        println("====================")
    }
}